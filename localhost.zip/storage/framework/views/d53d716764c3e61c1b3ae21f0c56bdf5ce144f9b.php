<?php $__env->startSection('content'); ?>
    <div class="container ">
        <div class="row justify-content-center ">
            <div class="d-flex gap-3">


                <div class="dropdown">
                    <h5>Вид чая:</h5>
                    <a class="btn btn-secondary dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-bs-toggle="dropdown" aria-expanded="false">
                        Все
                    </a>
                    <ul class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                        <li><a class="dropdown-item" href="#">Черный чай</a></li>
                        <li><a class="dropdown-item" href="#">Зеленый чай </a></li>
                    </ul>
                </div>

                <div class="dropdown">
                    <h5>Цена:</h5>
                    <a class="btn btn-secondary dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-bs-toggle="dropdown" aria-expanded="false">
                        Неважно
                    </a>
                    <ul class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                        <li><a class="dropdown-item" href="#">Сначала дороже</a></li>
                        <li><a class="dropdown-item" href="#">Сначала дешевле</a></li>
                    </ul>
                </div>

            </div>

                <div class="row row-cols-1 row-cols-md-4 g-4">

                <?php $__currentLoopData = $cards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <div  >
                            <div class="card h-100 ">
                                <a class="link-dark text-decoration-none" href="<?php echo e(route('product', $card->id)); ?>">
                                    <img src="/public/build/assets/img/<?php echo e($card->url); ?>" class="card-img-top " alt="...">

                                <div class="card-body d-flex flex-column justify-content-between">
                                    <h5 class="card-title"><?php echo e($card->nameProduct); ?></h5>
                                    <p class="card-text m-2">Вид чая: <?php echo e($card->status->typeOfTea); ?></p>

                                    <p class="card-text m-2">Цена: <?php echo e($card->price); ?> ₽</p>
                                    <div class="d-flex align-items-center gap-4">

                                            <a  href="<?php echo e(route('objectcart',$card->id)); ?>" class="btn btn-success ">Добавить в корзину</a>

                                            <a href=""><img  class="img-fluid" src="/public/build/assets/img/heartBlack.png" alt="" width="30" height="24"></a>



                                    </div>

                                </div>
                                </a>
                            </div>
                        </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\localhost\resources\views/catalog.blade.php ENDPATH**/ ?>