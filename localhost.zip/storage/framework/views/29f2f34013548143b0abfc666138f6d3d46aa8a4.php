<?php $__env->startSection('content'); ?>
    <div class="container">

    <table id="cart" class="table table-bordered">
        <thead>
        <tr>
            <td colspan="5" class=''>

                <div class="d-flex justify-content-between ">
                    <a href="<?php echo e(url('/catalog')); ?>" class="btn btn-primary">←</a>
                    <form method="POST" action="<?php echo e(route('clearCart')); ?>">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-danger">Очистить корзину</button>
                    </form>
                </div>
            </td>
        </tr>
        </thead>
        <thead>
        <tr>
            <th>Продукт</th>
            <th>Цена</th>

            <th></th>
        </tr>
        </thead>

        <tbody>
        <?php $total = 0 ?>
        <?php if(session('cart')): ?>
            <?php $__currentLoopData = session('cart'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <tr rowId="<?php echo e($id); ?>">
                    <td data-th="Product">

                        <div class="g-5 row">
                            <div class="col-sm-1 hidden-xs"><img src="/public/build/assets/img/<?php echo e($details['url']); ?>" class="card-img-top"/></div>
                            <div class="col-sm-9">

                                <h4 class="nomargin"><?php echo e($details['nameProduct']); ?></h4>
                            </div>
                        </div>
                    </td>
                    <td data-th="Price"><?php echo e($details['price']); ?>₽</td>


                    <td class="actions">

                        <a class="btn btn-danger delete-product" href="<?php echo e(route('remove-from-cart', $id)); ?>">Удалить</a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>


        </tbody>
        <tfoot>
        <tr>

            <td colspan="4" class="">
                <div class="d-flex justify-content-between ">
                    <p class="fs-5">Общая цена: <?php echo e(app()->make('App\Http\Controllers\ProductController')->getTotalPrice()); ?>₽</p>
                    <div><a href="<?php echo e(url('/catalog')); ?>" class="btn btn-success">Купить</a></div>

                </div>

            </td>
        </tr>
        </tfoot>

    </table>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\localhost\resources\views/cart.blade.php ENDPATH**/ ?>