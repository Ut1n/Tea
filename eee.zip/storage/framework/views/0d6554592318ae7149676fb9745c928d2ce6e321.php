<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row justify-content-center">
            <img src="/public/build/assets/img/<?php echo e($card->url); ?>" class="card-img-top " alt="...">
            <div><?php echo e($card->nameProduct); ?></div>
            <div><?php echo e($card->typeOfTea); ?></div>
            <div><?php echo e($card->description); ?></div>
            <div><?php echo e($card->price); ?></div>
            <div class="d-flex justify-content-between ">
                <div>
                    <a href=""><img class="img-fluid" src="/public/build/assets/img/heartBlack.png" alt="" width="30" height="24"></a>
                </div>
                <div>
                    <a href=""><img class="img-fluid" src="/public/build/assets/img/basketBlack.png" alt="" width="30" height="24"></a>
                </div>

            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\localhost\resources\views/post/productpage.blade.php ENDPATH**/ ?>